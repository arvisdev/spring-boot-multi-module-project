package com.arvisdev.ssmweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsmWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsmWebApplication.class, args);
	}

}
