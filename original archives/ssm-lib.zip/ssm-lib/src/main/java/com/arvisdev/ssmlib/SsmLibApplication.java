package com.arvisdev.ssmlib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsmLibApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsmLibApplication.class, args);
	}

}
